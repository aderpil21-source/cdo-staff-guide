# Проверка источника для v3

Репозиторий: `aderpil21-source/ranepa-dpo-site`  
Ветка: `main`  
Снимок дерева, использованный при разборе: `0fda042781961112872802ce4f34ef983516e1a9`

Основные просмотренные файлы:
- `index.html` — PRO-вход, 2FA UI, видимость, тексты, история, служебный портал учебных планов;
- `site-admin-workflow.js` — черновики, публикация, копии, корзина, восстановление;
- `site-admin-entities.js` — программы, контакты, FAQ, элементы, дизайн;
- `site-admin-structure.js` — расписание, меню, документы, блоки;
- `site-admin-media.js` — загрузка файлов, типы и лимиты;
- `site-admin-preview.js` — desktop/mobile и dark/light preview;
- `site-admin-diagnostics.js` — валидация и проверка внутренних ссылок;
- `site-admin-seo.js` — SEO страниц;
- `site-admin-overlay-dnd.js` — drag-and-drop порядка;
- `students-pro.js` — редактор страницы «Слушателям»;
- `schedule-page.js` — отсечение прошедшего дня в 21:00 Europe/Kaliningrad;
- `news.html` — редактор новостей, блоки, медиа, VK-предпочтение;
- `owl-engine.js` — служебные команды и переходы;
- `owl-operator.js`, `operator/app.py` — живой оператор и Telegram.

Секреты сознательно не переносились в инструкцию.
