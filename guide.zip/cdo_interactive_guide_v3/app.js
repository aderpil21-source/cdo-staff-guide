const $=(s,p=document)=>p.querySelector(s), $$=(s,p=document)=>[...p.querySelectorAll(s)];
const progress=$("#progress"); addEventListener("scroll",()=>{const h=document.documentElement.scrollHeight-innerHeight;progress.style.width=(scrollY/h*100)+"%"});
const toast=$("#toast"); $$("[data-copy]").forEach(b=>b.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(b.dataset.copy)}catch(e){const t=document.createElement("textarea");t.value=b.dataset.copy;document.body.append(t);t.select();document.execCommand("copy");t.remove()}toast.textContent="Скопировано";toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),1600)}));
const modal=$("#searchModal"), input=$("#searchInput"), results=$("#searchResults");
$("#searchOpen").onclick=()=>{modal.classList.add("open");modal.setAttribute("aria-hidden","false");setTimeout(()=>input.focus(),50)};
$("#searchClose").onclick=closeSearch; modal.addEventListener("click",e=>{if(e.target===modal)closeSearch()}); addEventListener("keydown",e=>{if(e.key==="Escape")closeSearch()});
function closeSearch(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true")}
const index=[
["МОЛНИЯ — срочное уведомление","#urgent","молния срочно перенос отмена аудитория 10 минут письмо"],
["Материалы преподавателя / ЛК-код","#materials","лк код материалы лекция презентация 1 минута"],
["Живой оператор / Telegram","#operator","оператор телеграм telegram ответ посетителю"],
["Заявки / Яндекс Формы","#applications","заявка яндекс форма договор автоматически email почта слушатель"],
["Новости","#news","новость публикация редактор фото теги"],
["PRO / редактирование сайта","#pro","pro пароль служебный вход изменить сайт"],
["Полный PRO / управление контентом","#cms","тексты видимость программы контакты faq меню документы блоки дизайн seo"],
["Программы — создать или изменить","#program-admin","программа pdf учебный план карточка часы цена формат"],
["Медиа и файлы","#media-admin","загрузить файл pdf docx pptx изображение видео аудио 100 500 мб"],
["История и диагностика","#history-diagnostics","отмена версия откат проверка ссылки ошибки"],
["Слушателям PRO","#students-pro","слушателям редактировать страницу скрыть блок ссылка"],
["Расписание","#schedule","расписание 21:00 архив дата"],
["Учебный план / PIN","#plans","учебный план pin пин портал"],
["Автоматическая почта","#mail","почта oxcidx rmail ranepa"],
["Что делать при ошибке","#errors","ошибка ctrl shift r f5 администратор"],
["Программы и контакты","#programs","программы контакты скрыть телефон"],
["Служебные данные","#credentials","пароль pin telegram ответственный"],
["Короткая памятка","#quick","памятка быстро"]
];
function render(q=""){const s=q.toLowerCase().trim();const rows=index.filter(x=>!s||x.join(" ").toLowerCase().includes(s));results.innerHTML=rows.map(x=>`<a href="${x[1]}"><b>${x[0]}</b><br><small>${x[2]}</small></a>`).join("")||"<p>Ничего не найдено. Попробуйте другое слово.</p>";$$("a",results).forEach(a=>a.onclick=closeSearch)}
input.addEventListener("input",()=>render(input.value)); render();
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.animate([{opacity:0,transform:"translateY(22px)"},{opacity:1,transform:"none"}],{duration:650,easing:"cubic-bezier(.2,.8,.2,1)",fill:"both"})}),{threshold:.08});
$$(".task,.steps>div,.operator-flow>div,.quick-grid>a,.columns article").forEach(el=>obs.observe(el));